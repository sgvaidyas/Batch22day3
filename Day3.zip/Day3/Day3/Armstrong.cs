﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 153
1+125+27 = 153
========================
sum =0
           x
n    n%10 rem^3 sum+=x  n=n/10
153  3     27     27    15
15   5     125    152   1
1    1     1      153   0 
*/

namespace Day3
{
    class Armstrong
    {
        static void Main(string[] args)
        {
            int n, sum=0,rem,x,cnt;
            string num;
            Console.WriteLine("Enter the n val = ");
            num = Console.ReadLine();
            cnt = num.Length;
            n = int.Parse(num);
            int n1 = n;
            while(n>0)
            {
                rem = n % 10;
                x = (int)Math.Pow(rem, cnt);
                sum += x;
                n /= 10;
            }
            if(n1==sum)
                Console.WriteLine(n1 + " is  Armstrong number");
            else
                Console.WriteLine(n1 + " is not  Armstrong number");

        }
    }
}
