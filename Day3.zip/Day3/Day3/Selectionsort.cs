﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Selectionsort
    {
        static void input(int[] a)
        {
            Console.WriteLine("Enter array elements ");
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = int.Parse(Console.ReadLine());
            }
        }
        static void print(int[] a)
        {
            Console.WriteLine("the array elements are=");
            foreach (int x in a)
            {
                Console.WriteLine(x);
            }
        }
        static void selection(int[] a)
        {
            int i, j, minind,n=a.Length;

            for(i=0;i<n-1;i++)
            {
                minind = i;
                for(j=i+1;j<n;j++)
                {
                    if(a[j] < a[minind])
                    {
                        minind = j;
                    }
                }
                int temp = a[i];
                a[i] = a[minind];
                a[minind] = temp;
            }
        }
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter num of elements ");
            n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            input(a);
            print(a);
            selection(a);
            print(a);
        }
    }
}
