﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Prime
    {
        static void Main(string[] args)
        {
            int n,i;
            Console.WriteLine("Enter the n val = ");
            n = int.Parse(Console.ReadLine());

            for(i=2;i<=n/2;i++)
            {
                if(n%i==0)
                {
                    Console.WriteLine(n+" is not prime number and i="+i);
                    break;
                }
            }
            if(i>n/2)
            {
                Console.WriteLine(n + " is prime number & i ="+i);
            }
        }
    }
}
