﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Fibonacci
    {
        static void Main(string[] args)
        {
            int n, i;
            Console.WriteLine("Enter the n val = ");
            n = int.Parse(Console.ReadLine());  

            if(n==0)
                Console.WriteLine(0);
            else if(n==1)
                Console.WriteLine(0 +"\n" + 1);
            else
            {
                int n1 = 0, n2 = 1, n3;
                Console.WriteLine(n1 + "\n" + n2);
                int cnt = 1;
                while(cnt<n)
                {
                    n3 = n1 + n2;
                    Console.WriteLine(n3);
                    n1 = n2;
                    n2 = n3;
                    cnt++;
                }

            }
        }
    }
}
