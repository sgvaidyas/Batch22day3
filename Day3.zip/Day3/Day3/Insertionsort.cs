﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Insertionsort
    {
        static void input(int[] a)
        {
            Console.WriteLine("Enter array elements ");
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = int.Parse(Console.ReadLine());
            }
        }
        static void print(int[] a)
        {
            Console.WriteLine("the array elements are=");
            foreach (int x in a)
            {
                Console.WriteLine(x);
            }
        }
        static void insertion(int[] a)
        {
            int i, j, key, n = a.Length;
            for (i = 1; i < n; i++)
            {
                key = a[i];
                j = i - 1;

                while (j >= 0 && a[j] > key)
                {
                    a[j + 1] = a[j];
                    j--;
                }
                a[j + 1] = key;
            }
        }
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter num of elements ");
            n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            input(a);
            print(a);
            insertion(a);
            print(a);
        }
    }
}
