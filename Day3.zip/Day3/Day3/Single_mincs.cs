﻿using System;
/*
 
    	11	2	3	4	1			
	    0	1	2	3	4			
								
n=5								
				a[i]	minind	a[minind]	if(a[i]<a[minind])	
min	1		    i=1	2	0	    11	        1<2	
minind	4		i=2	3	1	    2	        minind=4	
			    i=3	4	1	    2	        a[minind] =1	
			    i=4	1	1	    2		
								

 */

namespace Day3
{
    class Single_mincs
    {
        static void input(int[] a)
        {
            Console.WriteLine("Enter array elements ");
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = int.Parse(Console.ReadLine());
            }
        }
        static void print(int[] a)
        {
            Console.WriteLine("the array elements are=");
            foreach (int x in a)
            {
                Console.WriteLine(x);
            }
        }
        static int minindex(int[] a)
        {
            int minind = 0, min = a[0];
            for(int i = 1;i<a.Length;i++)
            {
                if(a[i]<min)
                {
                    minind = i;
                    min = a[i];
                }
            }
            return minind;
        }
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter num of elements ");
            n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            input(a);
            print(a);

            int minimum = a[ minindex(a)];
            for(int i =0;i<n;i++)
            {
                if(a[i]==minimum)
                    Console.WriteLine("Minimum value ={0} at {1}" , minimum,i);
            }
            
        }
    }
}
