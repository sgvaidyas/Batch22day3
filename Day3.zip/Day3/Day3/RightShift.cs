﻿using System;
/*
n=12345
51234
================
cnt = 5
x = n%10 -> 5
y = n/10 ->1234

x = 5* 10^(cnt-1) = 50000
x = x+y = 51234 
 */
namespace Day3
{
    class RightShift
    {
        static void Main(string[] args)
        {

            int n, cnt;
            string num;
            Console.WriteLine("Enter the n val = ");
            num = Console.ReadLine();
            cnt = num.Length;
            n = int.Parse(num);

            int x = n % 10;
            int y = n / 10;

            x = x * (int)(Math.Pow(10, cnt - 1));
            x = x + y;
            Console.WriteLine("Right shifted value of {0} is {1}",num,x);
        }
    }
}
