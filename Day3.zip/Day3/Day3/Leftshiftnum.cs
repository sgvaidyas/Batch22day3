﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3
{
    class Leftshiftnum
    {
        static void Main(string[] args)
        {
            int n, cnt;
            string num;
            Console.WriteLine("Enter the n val = ");
            num = Console.ReadLine();
            cnt = num.Length;
            n = int.Parse(num);

            int div = (int) Math.Pow(10, cnt - 1);
            int x = n % div;
            int y = n / div;

            x = x * 10 + y;
            Console.WriteLine("Left shifted value of {0} is {1}",n,x);
        }
    }
}
